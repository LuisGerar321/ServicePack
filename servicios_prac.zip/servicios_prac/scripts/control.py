import xbox
import os

#https://github.com/FRC4564/Xbox
#import my_saludo
joy = xbox.Joystick()         #Initialize joystick

my_input=' '

def Input_Controll():
	#button=' '
	my_dir= ' '
	if joy.A():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'A'
	else:
		pass	
	if joy.B():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'B'
	else:
		pass
	if joy.X():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'X'
	else:
		pass
	if joy.Y():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'Y'
	else:
		pass

	x_axis   = joy.leftX()        #X-axis of the left stick (values -1.0 to 1.0)
	y_axis = joy.leftY()
	(x,y)    = joy.leftStick()    #Returns tuple containing left X and Y axes (values -1.0 to 1.0)
	triggerR  = joy.rightTrigger() #Right trigger position (values 0 to 1.0)
	triggerL  = joy.leftTrigger()
	
	
	if(x_axis>=0.3 and y_axis==0):
		my_dir='d'
		##return my_dir
		
	elif(x_axis<=-0.3 and y_axis==0):
		my_dir='a'
		##return my_dir
		
	elif(y_axis>=0.3 and x_axis==0):
		my_dir='w'
		#return my_dir
		
	elif(y_axis<=-0.3 and x_axis==0):
		my_dir='s'
		#return my_dir
	#else:
	elif(triggerR>=0.5 and triggerL==0):
		my_dir='R'
	elif(triggerR==0 and triggerL>=0.5):
		my_dir='L'
	return my_dir
		
	



while True:
	my_input= Input_Controll()
	#my_saludo.welcome()
	print(my_input)
