#!/usr/bin/env python

import rospy
from serial import Serial
from gps.msg import RMC 
import os
from movilv2.srv import my_srv ## import my_srv.srv from your srv folder of your package


os.system("sudo chmod 666 /dev/ttyUSB0")
psoc= Serial('/dev/ttyUSB0',9600)
print("Psoc reading starting")


utc_r_=''
data_s_r_=''
ltd_r_=''
n_s_r_=''
lgt_r_=''
e_w_r_=''
s_knots_r_=''
track_=''
ut_date_r_=''
magnetic_r_=''
e_w_mag_r_=''
check_r_=''
latitude_=''
longitude_=''


list_message=[]
flag=1

prev_message=''

def S_GPS():

	global utc_r_
	global data_s_r_
	global ltd_r_
	global n_s_r_
	global lgt_r_
	global e_w_r_
	global s_knots_r_
	global track_
	global ut_date_r_
	global magnetic_r_
	global e_w_mag_r_
	global check_r_
	global latitude_
	global longitude_

	
	obj=RMC()

	global flag
	global prev_message
	# while flag:
	# 	message=psoc.readline()
	# 	list_message=message.split(",")
	# 	if(list_message[0]=="$GPRMC"):
	# 		flag=0
	# flag=1
	message=psoc.readline()
	list_message=message.split(",")
	if(list_message[0]=="$GPRMC"):
		prev_message=message
		message=message
		utc_r_=list_message[1]
		data_s_r_=list_message[2]
		ltd_r_=list_message[3]
		n_s_r_=list_message[4]
		lgt_r_=list_message[5]
		e_w_r_=list_message[6]
		s_knots_r_=list_message[7]
		track_=list_message[8]
		ut_date_r_=list_message[9]
		magnetic_r_=list_message[10]
		e_w_mag_r_=list_message[11]
		check_r_=list_message[12]
		latitude_=list_message[3]+ "," + list_message[4]
		longitude_= list_message[5] + "," + list_message[6]
	else:
		message=prev_message
		pass

	obj.utc_r=utc_r_
	obj.data_s_r=data_s_r_
	obj.ltd_r=ltd_r_
	obj.n_s_r =n_s_r_
	obj.lgt_r=lgt_r_
	obj.e_w_r=e_w_r_
	obj.s_knots_r=s_knots_r_
	obj.track=track_
	obj.ut_date_r=ut_date_r_
	obj.magnetic_r=magnetic_r_
	obj.e_w_mag_r=e_w_mag_r_
	obj.check_r=check_r_
	obj.latitude=latitude_
	obj.longitude= longitude_
	pub.publish(obj)


	scentral_server_ = rospy.ServiceProxy('scentral_server_', my_srv) ##Declare that you gonna send information of my_srv between service server #############33333
	resp2=scentral_server_(" ",message," ") #Send the three variables to server  ############################

	#rospy.loginfo(message)
	print(message)
	##print(list_message)


if __name__ == '__main__':
	try:

		rospy.init_node('S_GPS',anonymous=False) ##initialize a node just called nodea2
		pub=rospy.Publisher('topic_S_GPS',RMC,queue_size=20)  #Publish en a topic called "topic_ac2" the contained in cad_a2.msg
		rate=rospy.Rate(0.001) #set rate like an method of rospy.Rate

		while not rospy.is_shutdown():
			rospy.wait_for_service('scentral_server_')
			S_GPS()

	except rospy.ROSInterruptException:
		pass