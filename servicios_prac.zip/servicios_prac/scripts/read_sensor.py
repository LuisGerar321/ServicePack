#!/usr/bin/env python

import rospy
import os


from psoc_sensor.msg import data
from serial import Serial
from gps.msg import RMC
from movilv2.srv import my_srv ## import my_srv.srv from your srv folder of your package


puerto='1'
##os.system('sudo chmod 666 /dev/ttyACM' + puerto)
##psoc=Serial('/dev/ttyACM' + puerto, 9600);

os.system('sudo chmod 666 /dev/ttyACM' + puerto)
psoc=Serial('/dev/ttyACM' + puerto, 115200);



DistanceSensor=''
Encoder=''
GPS=' '



if __name__ == "__main__":
	rospy.init_node('psoc_sensor',anonymous=False) ##initialize a node just called nodea2
	
	obj=data()
	rate=rospy.Rate(0.01)

	pub=rospy.Publisher('topic_psoc_sensor',data,queue_size=20) #Publish en a topic called "topic_psoc_sensor" the contained in cad_data.msg
	#rospy.Subscriber('topic_S_GPS',RMC, downloading)
	##rospy.spin()


	try:

		while not rospy.is_shutdown():
			data_s=psoc.readline()
			obj.str=data_s
			#obj.str="$PSOC,x-xxxx,xxxxx\n"
			rospy.loginfo(obj.str)
			pub.publish(obj)

			rospy.wait_for_service('scentral_server_')
			scentral_server_ = rospy.ServiceProxy('scentral_server_', my_srv) ##Declare that you gonna send information of my_srv between service server #############33333
			resp2=scentral_server_(data_s," "," ") #Send the three variables to server  ############################

			pass

	except rospy.ROSInterruptException:
		pass
