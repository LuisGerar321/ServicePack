#!/usr/bin/env python
# coding=utf-8

import rospy 
import curses
import os
import time
from serial import Serial
from enum import Enum
from omnidirectional.msg import wheel
#import bluetooth
import sys
from os import system

from omnidirectional.msg import control
from omnidirectional.msg import wheel
from omnidirectional.srv import my_srv


# from os import system

##########################import xbox library ######################33
import xbox
import os

# os.system("sudo python xbox.py")
#import my_saludo
joy = xbox.Joystick()         #Initialize joystick

my_input=' '
key_press=False #Bandera para leer si esta presionado algun botton
key_dir=' ' #Boton para la direccion de la tecla
count=0

keyboard_action=' '  #Varables para el menu
keyboard_press=False
position_=1

def Input_Control():
	#button=' '
	global key_press

	my_dir= ' '
	if joy.A():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'A'
	else:
		pass	
	if joy.B():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'B'
	else:
		pass
	if joy.X():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'X'
	else:
		pass
	if joy.Y():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'Y'
	else:
		pass

	x_axis   = joy.leftX()        #X-axis of the left stick (values -1.0 to 1.0)
	y_axis = joy.leftY()
	(x,y)    = joy.leftStick()    #Returns tuple containing left X and Y axes (values -1.0 to 1.0)
	triggerR  = joy.rightTrigger() #Right trigger position (values 0 to 1.0)
	triggerL  = joy.leftTrigger()
	
	
	if(x_axis>=0.3 and y_axis==0):
		my_dir='d'
		##return my_dir
		
	elif(x_axis<=-0.3 and y_axis==0):
		my_dir='a'
		##return my_dir
		
	elif(y_axis>=0.3 and x_axis==0):
		my_dir='w'
		#return my_dir
		
	elif(y_axis<=-0.3 and x_axis==0):
		my_dir='s'
		#return my_dir
	#else:
	elif(triggerR>=0.5 and triggerL==0):
		my_dir='R'
	elif(triggerR==0 and triggerL>=0.5):
		my_dir='L'
#######################################################
	elif((x_axis<=-0.3) and (y_axis>=0.3)):
		my_dir='q'
	elif((x_axis<=-0.3) and (y_axis<=-0.3)):
		my_dir='z'
	elif((x_axis>=0.3) and (y_axis>=0.3)):
		my_dir='e'
	elif((x_axis>=0.3) and (y_axis<=-0.3)):
		my_dir='c'
#######################################################

	else:
		pass

	if(my_dir>' '):
		key_press=True

	elif(my_dir==' '):
		key_press=False
 
	return my_dir
#####################3




def send_serial(mself):
	my_str=mself+'#'
	for i in range(0,len(my_str)):
		psoc.write(my_str[i])
		time.sleep(0.01)


class Tecla(Enum):
	arriba='w'
	abajo='s'
	derecha='d'
	izquierda='a'
	parar='f'
	my_enter='x'
	my_space='z'
	bluetooth=1
	control=2
	exit='3'




##########################################################################
serial_input=" " ##Var que almacena lo que entra en el Rx

def pi_serial_send(self):
	if(pi.isOpen()==False):
		pi.open()
	else:
		pass
	pi.write(str(self))
	time.sleep(0.005)
	pi.flush()
	pi.close()

def pi_serial_read():
	
	if(pi.isOpen()==False):
		pi.open()
	else:
		pass

	_input=pi.read()
	time.sleep(0.01)
	pi.flush()
	pi.close()
	return _input

def pi_serial_read_line():
	
	if(pi.isOpen()==False):
		pi.open()
	else:
		pass

	_input=pi.readline()
	time.sleep(0.01)
	pi.flush()
	pi.close()
	return _input

def connection_check():
	if(pi.isOpen()==False):
		pi.open()
	else:
		pass

##########################################################################




# channel = "15"
# connection = ("sudo rfcomm connect 15 98:D3:32:20:50:64")
# system(connection)
# command_bluetooth = ("sudo chmod 666 /dev/rfcomm%s")%(channel)
# os.system(command_bluetooth)
# ###psoc = Serial("/dev/rfcomm0", 9600)
# ###os.system('sudo chmod 666 /dev/rfcomm0')
# command_serial = ('/dev/rfcomm%s')%(channel)
# pi=Serial(command_serial,9600)

# channel = "15"
# connection = ("sudo rfcomm connect 15 98:D3:32:20:50:64")
# system(connection)
# command_bluetooth = ("sudo chmod 666 /dev/rfcomm%s")%(channel)
# os.system("sudo chmod 666 /dev/rfcomm0")
# ###psoc = Serial("/dev/rfcomm0", 9600)
# ###os.system('sudo chmod 666 /dev/rfcomm0')
# # command_serial = ('/dev/rfcomm%s')%(channel)
# pi=Serial('/dev/rfcomm0',9600)


###message = "$PSOC,d,0,u,0,u,0,d,0"
message='-'




# rospy.init_node('Llantas',anonymous=False)
# pub=rospy.Publisher('TopicLlanta',wheel,queue_size=20)
# rate = rospy.Rate(10)

# obj=wheel()
os.system('clear')

menu_key=' '

##########################################  Key input  #####################################

from pynput.keyboard import Key, Listener #import pynput

def on_press(key): #Funcion para leer si esta presionada la tecla
	#print(" {0} pressed".format(key

	global keyboard_press
	global keyboard_action
	global position_
	keyboard_press=False
	

	if(key == Key.enter):
		##print("You are pressing up...")
		keyboard_action='x'
		keyboard_press=True
		#time.sleep(1)
		#return False
	elif(key == Key.backspace):
		##print("You are pressing up...")
		keyboard_action='z'
		keyboard_press=True
		#time.sleep(1)
		#return False

	elif(key == Key.down):
		if(position_>0 and position_<2):
			position_+=1

		else:
			position_=position_

		keyboard_action=Tecla.space.value
		keyboard_press=True
		#sleep(5)
		#return False

	elif(key == Key.up):
		if(position_>1):
			position_-=1
		else:

			position_=position_

		keyboard_action=Tecla.space.value
		keyboard_press=True
		#sleep(5)

	elif(key == Key.left):
		##print("You are pressing up...")
		keyboard_action='z'
		keyboard_press=True
		#time.sleep(1)
		#return False

	
	elif(key == Key.right):

		keyboard_action='x'
		keyboard_press=True
		##print("You are pressing up...")
		##keyboard_action=Tecla.back.value
		##key_press=True
		#time.sleep(1)
		#return False
		##sys.exit()
	else:
		keyboard_press=False
		position_=position_


	return False

def on_release(key): #Funcion para actualizar la  tecla
	global keyboard_press
	#print("PRESSING NOTHIN !!!!!")
	return False
####################    BLuetooth      ########################


# def bluetooth_connection():

# 	global pi

# 	lista_dispositivos=0

# 	lista = []
# 	key_action=' '
# 	bool_blue = True
# 	lista_addr=[]
# 	lista_names=[]
# 	number=0

# 	while bool_blue==True:
# 		print("Finding a device...\n")
# 		lista=bluetooth.discover_devices(duration=10, lookup_names = True)
# 		print ("Lista de Dispositivos Bluetooth")
# 		print ("Se encontraron %d" % len(lista))
# 		for addr, name in lista:
# 			print ("%s – %s" % (addr, name))
# 			lista_addr.append(addr)
# 			lista_names.append(name)
# 			key_action=str(raw_input("Do you want to search again? Y/N\n"))
# 		if (key_action=='Y' or key_action=='y'):
# 			lista_addr=[]
# 			lista_names=[]
# 		if(key_action=='N' or key_action=='n'):
# 			bool_blue=False
# 			break
# 	for name in lista_names:
# 		number += 1
# 		print("%d. %s")%(number, name)

# 	MAC = input("Choose the Bluetooth number on the list that you want to connect : ")
# 	if MAC == 1:
# 		command1 = ("sudo rfcomm connect hci0 %s 2")%(lista_addr[0])
# 		system(command1)
# 	elif MAC == 2:
# 		command2 = ("sudo rfcomm connect hci0 %s 2")%(lista_addr[1])
# 		system(command2)
# 	elif MAC == 3:
# 		command3 = ("sudo rfcomm connect hci0 %s 2")%(lista_addr[2])
# 		system(command3)
# 	elif MAC == 4:
# 		command4 = ("sudo rfcomm connect hci0 %s 2")%(lista_addr[3])
# 		system(command4) 
# 	elif MAC == 5:
# 		command5 = ("sudo rfcomm connect hci0 %s 2")%(lista_addr[4])
# 		system(command5)
# 	elif MAC == 6:
# 		command6 = ("sudo rfcomm connect hci0 %s 2")%(lista_addr[5])
# 		system(command6)
# 	elif MAC == 7:
# 		command7 = ("sudo rfcomm connect hci0 %s 2")%(lista_addr[6])
# 		system(command7) 
# 	elif MAC == 8:
# 		command8 = ("sudo rfcomm connect hci0 %s 2")%(lista_addr[7])
# 		system(command8)
# 	elif MAC == 9:
# 		command9 = ("sudo rfcomm connect hci0 %s 2")%(lista_addr[8])
# 		system(command9)
# 	elif MAC == 10:
# 		command10 = ("sudo rfcomm connect hci0 %s 2")%(lista_addr[9])
# 		system(command10)		

# 	system("blueman-manager & disown")

# 	rfcomm = str(input("Enter your rfcomm: "))

# 	str5 = ("sudo chmod 666 /dev/rfcomm%s")%(rfcomm)
# 	str6 = ('/dev/rfcomm%s')%(rfcomm)
# 	os.system(str5)
# 	pi=Serial(str6,9600)

# 	print("Program finished")






################################################################################################
def downloading(parametros):
	#_sensor=parametros.ultrasonico
	#_latitud=parametros.latitud
	#_longitud=parametros.longitud
	#_altitud=parametros.ams
	print(("distancia: %s \n  latitud: %s \n longitud: %s \n altitud: %s \n ")%(parametros.dir,parametros.latitud,parametros.longitud, parametros.encoder))
	pub = rospy.Publisher('topic_control', wheel, queue_size = 20)
	rate = rospy.Rate(10)
	ob = wheel()
	bar = 100
	input_c = Input_Control()
	if input_c == ' ':
		input_c = '-'

	ob.direction = input_c
	pub.publish(ob)


	scentral_server_ = rospy.ServiceProxy('my_server_', my_srv) ##Declare that you gonna send information of my_srv between service server #############33333
	resp2=scentral_server_(" "," "," ",input_c) #Send the three variables to server  ############################

	if input_c == 'w':
		input_c = u'\u2191'
	elif input_c == 's':
		input_c = u'\u2193'
	elif input_c == 'd':
		input_c = u'\u2192'
	elif input_c == 'a':
		input_c = u'\u2190'
	elif input_c == 'L':
		input_c = u'\u21b7'
		if bar == 100:
			print("█""█""█""█""█""█""█""█""█""█""100%")
			bar = 100
		elif bar == 90:
			print("█""█""█""█""█""█""█""█""█""90%")
			bar+=10
		elif bar == 80:
			print("█""█""█""█""█""█""█""█""80%")
			bar+=10
		elif bar == 70:
			print("█""█""█""█""█""█""█""70%")
			bar+=10
		elif bar == 60:
			print("█""█""█""█""█""█""60%")
			bar+=10
		elif bar == 50:
			print("█""█""█""█""█""50%")
			bar+=10
		elif bar == 40:
			print("█""█""█""█""40%")
			bar+=10
		elif bar == 30:
			print("█""█""█""30%")
			bar+=10
		elif bar == 20:
			print("█""█""20%")
			bar+=10
		elif bar == 10:
			print("█""10%")
			bar+=10
		elif bar == 0:
			print(" ""90%")
			bar = 0	

	elif input_c == 'R':
		if bar == 100:
			print("█""█""█""█""█""█""█""█""█""█""100%")
			bar-=10
		elif bar == 90:
			print("█""█""█""█""█""█""█""█""█""90%")
			bar-=10
		elif bar == 80:
			print("█""█""█""█""█""█""█""█""80%")
			bar-=10
		elif bar == 70:
			print("█""█""█""█""█""█""█""70%")
			bar-=10
		elif bar == 60:
			print("█""█""█""█""█""█""60%")
			bar-=10
		elif bar == 50:
			print("█""█""█""█""█""50%")
			bar-=10
		elif bar == 40:
			print("█""█""█""█""40%")
			bar-=10
		elif bar == 30:
			print("█""█""█""30%")
			bar-=10
		elif bar == 20:
			print("█""█""20%")
			bar-=10
		elif bar == 10:
			print("█""10%")
			bar-=10
		elif bar == 0:
			print(" ""0%")
			bar = 0								
		# input_c = u'\u21b6'

	rospy.loginfo(' ')
	#a=detectarObstaculo
	#print(a)

	print(input_c)
	rate.sleep()
	time.sleep(0.1)
	system("clear")		


##############################################################################################
def robot_control():
	
	global key_dir
	global key_press
	global message
	global count


	while(True):

		#listener= Listener(on_press=on_press,on_release=on_release)
		#listener.start()

		serial_dir=' '
		###pi.write('r')
		###if pi.readline() == 'OK\n':
		connection_check() #Check if the port is open
		key_dir=Input_Control()
		# try:
		# print(serial_dir)
		# except: 
		# 	pass

		if key_press:

			# print(serial_dir)
		
			count=0
			# emptylist = []
			# emptylist.append(serial_dir)
			if(key_dir==Tecla.arriba.value):
				
				print(u'\u2191')
				###message="$PSOC,u,70,u,70,u,70,u,70"
				message='w' #.
				pi_serial_send(message) #This function write in Tx buffer #.	
				###send_serial(message)
				count=0
				#psoc.flush()

			elif(key_dir==Tecla.abajo.value):
				print(u'\u2193')
				###message="$PSOC,d,70,d,70,d,70,d,70"
				message='s' #.
				pi_serial_send(message) #This function write in Tx buffer #.	
				#send_serial(message)
				count=0
				#psoc.flush()
				#psoc.write('s')
			elif (key_dir=='d'):
				print(u'\u2192')
				###message="$PSOC,u,70,d,70,d,70,u,70"
				message='d' #.
				###send_serial(message)
				pi_serial_send(message) #This function write in Tx buffer #.
				count=0
				#psoc.flush()
				#psoc.write('d')
			elif (key_dir=='a'):
				print(u'\u2190')
				###message="$PSOC,d,70,u,70,u,70,d,70"
				message='a' #.
				###send_serial(message)
				pi_serial_send(message) #This function write in Tx buffer #.
				count=0
				#psoc.flush()
			elif (key_dir=='z'):
				print(u'\u21b7')
				###message="$PSOC,u,70,d,70,u,70,d,70"
				message='z'  #.
				###send_serial(message)
				pi_serial_send(message) #This function write in Tx buffer #.
				count=0
				#psoc.flush()
			elif (key_dir=='x'):
				print(u'\u21b6')
				###message="$PSOC,d,70,u,70,d,70,u,70"
				message='x' #.
				###send_serial(message)
				pi_serial_send(message) #This function write in Tx buffer #.
				count=0
				#psoc.flush()

		else:
			print(u'\u26d4')
			count+=1

			###message="$PSOC,d,0,u,0,d,0,u,0"
			message='-'

			# print(count)
			if(count==2):
				###message="$PSOC,d,0,u,0,d,0,u,0"
				message='-'
				pi_serial_send(message) #This function write in Tx buffer #.
				count=0
			pi_serial_send(message) #This function write in Tx buffer #.
			###send_serial(message)

		# if(pi.isOpen()==False):
		# 	pi.open()
		# else:
		# 	pass
		# serial_dir=pi.readline()

		key_press=False
		list1=message.split(',')

			# obj.wheel1_dir=list1[1]
			# obj.wheel1_vel=list1[2]
			# obj.wheel2_dir=list1[3]
			# obj.wheel2_vel=list1[4]
			# obj.wheel3_dir=list1[5]
			# obj.wheel3_vel=list1[6]
			# obj.wheel4_dir=list1[7]
			# obj.wheel4_vel=list1[8]

			# pub.publish(obj)


			##sleep(0.02)
		os.system('clear')
			#listener.stop()

		
		#else:
		
			#pass
		
		# sleep(1)

	psoc.close()
	os.system("clear")

	

def talker():

	########while not rospy.is_shutdown():
	try:
		rospy.Subscriber("topic_central",control, downloading)
	except:
		pass
	print("Hola mundo\n")
	rospy.spin()
	rate.sleep()

	# ob = wheel()
	# bar = 100
	# input_c = Input_Controll()
	# if input_c == ' ':
	# 	input_c = '-'

	# ob.direction_wheels = input_c
	# pub.publish(ob)

	# if input_c == 'w':
	# 	input_c = u'\u2191'
	# elif input_c == 's':
	# 	input_c = u'\u2193'
	# elif input_c == 'd':
	# 	input_c = u'\u2192'
	# elif input_c == 'a':
	# 	input_c = u'\u2190'
	# elif input_c == 'L':
	# 	input_c = u'\u21b7'
	# 	if bar == 100:
	# 		print("█""█""█""█""█""█""█""█""█""█""100%")
	# 		bar = 100
	# 	elif bar == 90:
	# 		print("█""█""█""█""█""█""█""█""█""90%")
	# 		bar+=10
	# 	elif bar == 80:
	# 		print("█""█""█""█""█""█""█""█""80%")
	# 		bar+=10
	# 	elif bar == 70:
	# 		print("█""█""█""█""█""█""█""70%")
	# 		bar+=10
	# 	elif bar == 60:
	# 		print("█""█""█""█""█""█""60%")
	# 		bar+=10
	# 	elif bar == 50:
	# 		print("█""█""█""█""█""50%")
	# 		bar+=10
	# 	elif bar == 40:
	# 		print("█""█""█""█""40%")
	# 		bar+=10
	# 	elif bar == 30:
	# 		print("█""█""█""30%")
	# 		bar+=10
	# 	elif bar == 20:
	# 		print("█""█""20%")
	# 		bar+=10
	# 	elif bar == 10:
	# 		print("█""10%")
	# 		bar+=10
	# 	elif bar == 0:
	# 		print(" ""90%")
	# 		bar = 0	

	# elif input_c == 'R':
	# 	if bar == 100:
	# 		print("█""█""█""█""█""█""█""█""█""█""100%")
	# 		bar-=10
	# 	elif bar == 90:
	# 		print("█""█""█""█""█""█""█""█""█""90%")
	# 		bar-=10
	# 	elif bar == 80:
	# 		print("█""█""█""█""█""█""█""█""80%")
	# 		bar-=10
	# 	elif bar == 70:
	# 		print("█""█""█""█""█""█""█""70%")
	# 		bar-=10
	# 	elif bar == 60:
	# 		print("█""█""█""█""█""█""60%")
	# 		bar-=10
	# 	elif bar == 50:
	# 		print("█""█""█""█""█""50%")
	# 		bar-=10
	# 	elif bar == 40:
	# 		print("█""█""█""█""40%")
	# 		bar-=10
	# 	elif bar == 30:
	# 		print("█""█""█""30%")
	# 		bar-=10
	# 	elif bar == 20:
	# 		print("█""█""20%")
	# 		bar-=10
	# 	elif bar == 10:
	# 		print("█""10%")
	# 		bar-=10
	# 	elif bar == 0:
	# 		print(" ""90%")
	# 		bar = 0								
	# 	# input_c = u'\u21b6'

	# rospy.loginfo(' ')
	# #a=detectarObstaculo
	# #print(a)

	# print(input_c)
	# rate.sleep()
	# system("clear")	
def camara_pi():
	ip = raw_input("Enter your raspberry ip: ")
	ip_connection = "ssh -X pi@%s" % (ip)
	# print(ip_connection)
	system(ip_connection)
	# system("raspberry")	

my_des=' '

# 	MAIN   	#

rospy.init_node('control_node', anonymous = True)
pub = rospy.Publisher('topic_control', wheel, queue_size = 10) ##20
rate = rospy.Rate(10)
ob = wheel()

while True:


	print("1-. Configurar Bluetooth\n2-. Control\n3-. Camara")
	my_des=raw_input("Put a number: ")

	if(my_des=='1'):
		bluetooth_connection()
	elif my_des == '2':

		# robot_control()
		while True:
			talker()
	elif my_des == '3':
		camara_pi()


	my_des=' ' 
	
GPIO.cleanup()
#robot_control()


# ################################   ##  Menu ##       ######################################3

# while True:

# 	listener= Listener(on_press=on_press,on_release=on_release) #+
# 	listener.start() #+		

# 	print("\tRobot Beta\n")

# 	if(position_==1):
# 		print("1-. Configurar Bluetooth <--\n2-. Control\n")
# 	elif(position_==2):
# 		print("1-. Configurar Bluetooth\n2-. Control <--\n")
# 	elif(position_==0):
# 		print("1-. Configurar Bluetooth ***\n2-. Control\n")

# 	#while(menu_key<'1' or menu_key>'3'):
# 		#menu_key=raw_input('Push a number\n')

# 	if(position_==Tecla.bluetooth.value and keyboard_action=='x'):
# 		os.system('clear')
# 		listener.stop()
# 		keyboard_action= ' '
# 		while True:
			
# 			listener= Listener(on_press=on_press,on_release=on_release) #+
# 			listener.start() #+

# 			print('Estas configurando el Bluetooth...\n')
# 			sleep(0.075)

# 			##### Put your code here !!!! #####




# 			###############################


# 			if(keyboard_action=='z'):
# 				listener.stop()
# 				keyboard_action=' '
# 				break

# 			listener.stop() #+
	
# 	elif(position_==Tecla.control.value and keyboard_action=='x'):

# 	    os.system('clear')
# 	    listener.stop()
# 	    keyboard_action= ' '
# 	    while True:
# 	    	#listener= Listener(on_press=on_press,on_release=on_release) #+
# 	    	#listener.start() #+

# 	    	########## Put your code her !!!! ############
# 	    	connection_check() #Check if the port is open
# 	    	key_dir=Input_Controll()
# 	    	if key_press:
# 	    		count=0
# 	    		if(key_dir==Tecla.arriba.value):	
# 	    			print("Estoy arriba!!")
# 	    			###message="$PSOC,u,70,u,70,u,70,u,70"
# 	    			message='w' #.
# 	    			pi_serial_send(message) #This function write in Tx buffer #.	
# 	    			###send_serial(message)
# 	    			count=0
# 	    			#psoc.flush()
# 	    		elif(key_dir==Tecla.abajo.value):
# 	    			print("Esto	y abajo!!")
# 	    			###message="$PSOC,d,70,d,70,d,70,d,70"
# 	    			message='s' #.
# 	    			pi_serial_send(message) #This function write in Tx buffer #.	
# 	    			#send_serial(message)
# 	    			count=0
# 	    			#psoc.flush()
# 	    			#psoc.write('s')
# 	    		elif (key_dir=='d'):
# 	    			print("Estoy derecha!!")
# 	    			###message="$PSOC,u,70,d,70,d,70,u,70"
# 	    			message='d' #.
# 	    			###send_serial(message)
# 	    			pi_serial_send(message) #This function write in Tx buffer #.
# 	    			count=0
# 	    			#psoc.flush()
# 	    			#psoc.write('d')
# 	    		elif (key_dir=='a'):
# 	    			print("Estoy izquierda!!")
# 	    			###message="$PSOC,d,70,u,70,u,70,d,70"
# 	    			message='a' #.
# 	    			###send_serial(message)
# 	    			pi_serial_send(message) #This function write in Tx buffer #.
# 	    			count=0
# 	    			#psoc.flush()
# 	    		elif (key_dir=='z'):
# 	    			print("Estoy girando derecha!!")
# 	    			###message="$PSOC,u,70,d,70,u,70,d,70"
# 	    			message='z'  #.
# 	    			###send_serial(message)
# 	    			pi_serial_send(message) #This function write in Tx buffer #.
# 	    			count=0
# 	    			#psoc.flush()
# 	    		elif (key_dir=='x'):
# 	    			print("Estoy girando izquierda!!")
# 	    			###message="$PSOC,d,70,u,70,d,70,u,70"
# 	    			message='x' #.
# 	    			###send_serial(message)
# 	    			pi_serial_send(message) #This function write in Tx buffer #.
# 	    			count=0
# 	    			#psoc.flush()
# 			###########else:
# 				##########print("Estoy apagado")
# 				############count+=1
# 				###message="$PSOC,d,0,u,0,d,0,u,0"
# 				#############3message='-'
# 				##############print(count)
# 				##########if(count==2):
# 					###message="$PSOC,d,0,u,0,d,0,u,0"
# 					#################33message='-'
# 					###############33pi_serial_send(message) #This function write in Tx buffer #.
# 					###############3count=0
# 					##################pi_serial_send(message) #This function write in Tx buffer #.
# 				###send_serial(message)
# 				##########################pi_serial_send(message)
# ###########################################################
# 			elif(key_press==False):
# 				print("Estoy apagado")
# 				count+=1
# 				###message="$PSOC,d,0,u,0,d,0,u,0"
# 				message='-'
# 				print(count)
# 				if(count==2):
# 					###message="$PSOC,d,0,u,0,d,0,u,0"
# 					message='-'
# 					pi_serial_send(message) #This function write in Tx buffer #.
# 					count=0
# 					#pi_serial_send(message) #This function write in Tx buffer #.
# 				###send_serial(message)
# 				pi_serial_send(message)


# 			key_press=False
# 			list1=message.split(',')

# 				# obj.wheel1_dir=list1[1]
# 				# obj.wheel1_vel=list1[2]
# 				# obj.wheel2_dir=list1[3]
# 				# obj.wheel2_vel=list1[4]
# 				# obj.wheel3_dir=list1[5]
# 				# obj.wheel3_vel=list1[6]
# 				# obj.wheel4_dir=list1[7]
# 				# obj.wheel4_vel=list1[8]

# 				# pub.publish(obj)


# 				##sleep(0.02)
			
# 			os.system('clear')
# 			if(keyboard_action=='z'):
# 				message='-'
# 				pi_serial_send(message)
# 				listener.stop()
# 				keyboard_action=' '
# 				break


# 	    	#print('Estas controlando el Robot...\n')
# 	    	#sleep(0.075)
# 	    	####listener.stop() #+


# 	elif(keyboard_action==Tecla.exit.value):
# 		sys.exit()

# 	else:
# 		pass
# 	print('Position now: %s' %position_)
# 	print('keyboard_action now: %s'%keyboard_action)
# 	sleep(0.075)		
# 	os.system('clear')
# 	##Cleaning var
# 	menu_key=' '
# 	#keyboard_action=' '
# 	listener.stop()#+

# psoc.close()
# os.system("clear")


###############################     No menu       #############################################
# while(True):

# 	#listener= Listener(on_press=on_press,on_release=on_release)
# 	#listener.start()


# 	###pi.write('r')
# 	###if pi.readline() == 'OK\n':


# 	connection_check() #Check if the port is open
# 	key_dir=Input_Controll()

# 	if key_press:
# 		count=0
# 		if(key_dir==Tecla.arriba.value):
			
# 			print("Estoy arriba!!")
# 			###message="$PSOC,u,70,u,70,u,70,u,70"
# 			message='w' #.
# 			pi_serial_send(message) #This function write in Tx buffer #.	
# 			###send_serial(message)
# 			count=0
# 			#psoc.flush()

# 		elif(key_dir==Tecla.abajo.value):
# 			print("Esto	y abajo!!")
# 			###message="$PSOC,d,70,d,70,d,70,d,70"
# 			message='s' #.
# 			pi_serial_send(message) #This function write in Tx buffer #.	
# 			#send_serial(message)
# 			count=0
# 			#psoc.flush()
# 			#psoc.write('s')
# 		elif (key_dir=='d'):
# 			print("Estoy derecha!!")
# 			###message="$PSOC,u,70,d,70,d,70,u,70"
# 			message='d' #.
# 			###send_serial(message)
# 			pi_serial_send(message) #This function write in Tx buffer #.
# 			count=0
# 			#psoc.flush()
# 			#psoc.write('d')
# 		elif (key_dir=='a'):
# 			print("Estoy izquierda!!")
# 			###message="$PSOC,d,70,u,70,u,70,d,70"
# 			message='a' #.
# 			###send_serial(message)
# 			pi_serial_send(message) #This function write in Tx buffer #.
# 			count=0
# 			#psoc.flush()
# 		elif (key_dir=='z'):
# 			print("Estoy girando derecha!!")
# 			###message="$PSOC,u,70,d,70,u,70,d,70"
# 			message='z'  #.
# 			###send_serial(message)
# 			pi_serial_send(message) #This function write in Tx buffer #.
# 			count=0
# 			#psoc.flush()
# 		elif (key_dir=='x'):
# 			print("Estoy girando izquierda!!")
# 			###message="$PSOC,d,70,u,70,d,70,u,70"
# 			message='x' #.
# 			###send_serial(message)
# 			pi_serial_send(message) #This function write in Tx buffer #.
# 			count=0
# 			#psoc.flush()
				
# 	else:
# 		print("Estoy apagado")
# 		count+=1
# 		###message="$PSOC,d,0,u,0,d,0,u,0"
# 		message='-'

# 		print(count)
# 		if(count==2):
# 			###message="$PSOC,d,0,u,0,d,0,u,0"
# 			message='-'
# 			pi_serial_send(message) #This function write in Tx buffer #.
# 			count=0
# 		pi_serial_send(message) #This function write in Tx buffer #.
# 		###send_serial(message)
		
# 	key_press=False
# 	list1=message.split(',')

# 		# obj.wheel1_dir=list1[1]
# 		# obj.wheel1_vel=list1[2]
# 		# obj.wheel2_dir=list1[3]
# 		# obj.wheel2_vel=list1[4]
# 		# obj.wheel3_dir=list1[5]
# 		# obj.wheel3_vel=list1[6]
# 		# obj.wheel4_dir=list1[7]
# 		# obj.wheel4_vel=list1[8]

# 		# pub.publish(obj)


# 		##sleep(0.02)
# 	os.system('clear')
# 		#listener.stop()

	
# 	#else:
	
# 		#pass
	
# 	# sleep(1)

# psoc.close()
# os.system("clear")


#################################################################



	