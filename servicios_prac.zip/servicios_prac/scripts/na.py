#!/usr/bin/env python

import rospy ##import rospy library to use python
import sys
import time

from servicios_prac.srv import my_srv_b ## import my_srv.srv from your srv folder of your package
from servicios_prac.srv import my_srv_c ## import my_srv.srv from your srv folder of your package


if __name__ == '__main__':
	rospy.init_node('NA', anonymous = True)
	rate = rospy.Rate(10)
	scentral_server_1 = rospy.ServiceProxy('server_nb', my_srv_b) ##Declare that you gonna send information of my_srv between service server #############33333
	scentral_server_2 = rospy.ServiceProxy('server_nc', my_srv_c) ##Declare that you gonna send information of my_srv between service server #############33333
	number = sys.argv[1]

	if((float(number)%2)==0):
		print("Number par enviando al servicio  nb" + str(number)+ "\n")
		resp2=scentral_server_1(str(number)," ") #Send the three variables to server  ############################
	else:
		print("Number par enviando al servicio  nc" + str(number)+ "\n")
		resp2=scentral_server_2(str(number)," ") #Send the three variables to server  ############################
		##time.sleep(0.5)