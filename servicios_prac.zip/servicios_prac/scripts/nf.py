#!/usr/bin/env python

import rospy ##import rospy library to use python
from servicios_prac.srv import my_srv_b ## import my_srv.srv from your srv folder of your package
from servicios_prac.srv import my_srv_c ## import my_srv.srv from your srv folder of your package
from servicios_prac.srv import my_srv_d ## import my_srv.srv from your srv folder of your package
from servicios_prac.srv import my_srv_f ## import my_srv.srv from your srv folder of your package

import time ## import time to use sleep
import os


def handle_info(data): ## Service info (my_srv)
	my_data=data.data1  ## take the information of the variable nm on my_srv
	print(("Nodo_f: %s")%(my_data))
	return float(my_data)		## you can skip it



def service_server():
    rospy.init_node('nf') ## Create a new node called  node_central
    s = rospy.Service('server_nf',my_srv_f, handle_info) ## declare s as Service server type, save the 
    
    print "Ready to read." ## Print a message
    time.sleep(0.5) ## wait 0.5 seconds
    rospy.spin() ## Do this for ever

if __name__ == '__main__':
	service_server() ##Execute  service_server function