import xbox
import os

# os.system("sudo python xbox.py")
#import my_saludo
joy = xbox.Joystick()         #Initialize joystick

my_input=' '
key_press=False #Bandera para leer si esta presionado algun botton
key_dir=' ' #Boton para la direccion de la tecla
count=0

keyboard_action=' '  #Varables para el menu
keyboard_press=False
position_=1

def Input_Controll():
	#button=' '
	global key_press

	my_dir= ' '
	if joy.A():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'A'
	else:
		pass	
	if joy.B():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'B'
	else:
		pass
	if joy.X():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'X'
	else:
		pass
	if joy.Y():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'Y'
	else:
		pass

	x_axis   = joy.leftX()        #X-axis of the left stick (values -1.0 to 1.0)
	y_axis = joy.leftY()
	(x,y)    = joy.leftStick()    #Returns tuple containing left X and Y axes (values -1.0 to 1.0)
	triggerR  = joy.rightTrigger() #Right trigger position (values 0 to 1.0)
	triggerL  = joy.leftTrigger()
	
	
	if(x_axis>=0.3 and y_axis==0):
		my_dir='d'
		##return my_dir
		
	elif(x_axis<=-0.3 and y_axis==0):
		my_dir='a'
		##return my_dir
		
	elif(y_axis>=0.3 and x_axis==0):
		my_dir='w'
		#return my_dir
		
	elif(y_axis<=-0.3 and x_axis==0):
		my_dir='s'
		#return my_dir
	#else:
	elif(triggerR>=0.5 and triggerL==0):
		my_dir='R'
	elif(triggerR==0 and triggerL>=0.5):
		my_dir='L'

	else:
		pass

	if(my_dir>' '):
		key_press=True

	elif(my_dir==' '):
		key_press=False
 
	return my_dir
#####################3
