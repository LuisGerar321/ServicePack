#!/usr/bin/env python

import rospy ##import rospy library to use python
from servicios_prac.srv import my_srv_d ## import my_srv.srv from your srv folder of your package
from servicios_prac.srv import my_srv_t ## import my_srv.srv from your srv folder of your package
from servicios_prac.srv import my_srv_f ## import my_srv.srv from your srv folder of your package
import time ## import time to use sleep
import os

my_fact=0.0
my_sum_ = 0.0

def handle_info(data): ## Service info (my_srv)

	global my_sum_
	global my_fact

	scentral_server_1 = rospy.ServiceProxy('server_nt', my_srv_t) ##Declare that you gonna send information of my_srv between service server #############33333
	scentral_server_2 = rospy.ServiceProxy('server_nf', my_srv_f) ##Declare that you gonna send information of my_srv between service server #############33333

	if(data.data1>' '):
		my_sum_=data.data1  ## take the information of the variable nm on my_srv
	if(data.data2>' '):
		my_fact=data.data2

	if(my_sum_>' ' and my_fact>' '):

		result_mult = float(my_sum_) * float(my_fact)
		result_sum = float(my_sum_) + float(my_fact)
		if(result_sum>result_mult):
			print("Hola mundo\n")


		rospy.loginfo("NB=%s    NC=%s\n" %(my_sum_, my_fact))  ## Print info to group2 (nodea2, nodeb2, nodec2)
		rospy.loginfo("La mult = %s\t La sum = %s\n" %(result_mult, result_sum))  ## Print info to group2 (nodea2, nodeb2, nodec2)

		resp1=scentral_server_1(str(my_sum_)," ") #Send the three variables to server  ############################
		resp2=scentral_server_2(str(my_fact)," ") #Send the three variables to server  ############################

		return result_mult
	else:
		rospy.loginfo("NB=%s    NC=%s\n" %(my_sum_, my_fact))  ## Print info to group2 (nodea2, nodeb2, nodec2)
		return 0


def service_server():
    rospy.init_node('nd') ## Create a new node called  node_central
    s = rospy.Service('server_nd',my_srv_d, handle_info) ## declare s as Service server type, save the

    print "Ready to read." ## Print a message
    time.sleep(0.5) ## wait 0.5 seconds
    rospy.spin() ## Do this for ever

if __name__ == '__main__':
	service_server() ##Execute  service_server function