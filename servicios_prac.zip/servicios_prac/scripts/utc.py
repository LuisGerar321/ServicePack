hora= raw_input("Ingresa la hora\t")
min = raw_input("\nIngresa los min\t")
sec = raw_input("\ningresa los segundos\t")

h=int(hora)
m=int(min)
s=int(sec)

if(h==0):
    h=24
elif(h>=0 and h<6):
    h=24+(h-6)
else:
    h=h-6
print(("%d.%d.%d")%(h,m,s))


