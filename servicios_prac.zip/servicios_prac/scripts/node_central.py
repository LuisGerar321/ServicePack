#!/usr/bin/env python

import rospy ##import rospy library to use python
from movilv2.srv import my_srv ## import my_srv.srv from your srv folder of your package
import time ## import time to use sleep
import os

from movilv2.msg import controll

my_distace=''
my_gps=''
my_encoder=''

obj_dist=''

def handle_info(camara): ## Service info (my_srv)

	global my_distace
	global my_gps
	global my_encoder
	global obj_dist

	obj=controll()
	pub=rospy.Publisher('topic_central',controll, queue_size=20)
	print "Hola..."

	dis=camara.distance  ## take the information of the variable nm on my_srv
	g=camara.gps ## take the information of the variable ap on my_srv
	ec=camara.encoder ## take the information of the variable ed on my_srv
	control= camara.dir_control

	if dis>' ':
		my_distace=dis
		my_list=my_distace.split(',')
		obj_dist=my_list[2]
	else:
		my_distace=my_distace
	
	if g>' ':
		my_gps=g
	else:
		my_gps=my_gps
	
	if ec>' ':
		my_encoder=ec
	else:
		my_encoder=my_encoder

	obj.dir=dis
	pub.publish(obj)
	# if float(obj_dist)<20:
	# 	obj.dir='w'
	# 	pub.publish(obj)
	# else:
	# 	obj.dir='-'
	# 	pub.publish(obj)


	#1-. Read input controll
	#2-. obj.dir = Input controll
	#3-. Publicar obj
	#4-. Mostrar en pantalla
	
	rospy.loginfo(("psoc:%s, gps %s ec %s dir %s\n")%(my_distace, my_gps, my_encoder,control))  ## Print info to group2 (nodea2, nodeb2, nodec2)
	#print(dis)


	val = 10 ##return mi edad in sum
	return val		## you can skip it

def service_server():
    rospy.init_node('nodo_central') ## Create a new node called  node_central
    s = rospy.Service('my_server_',my_srv, handle_info) ## declare s as Service server type, save the  
    obj=controll() ########new
    pub=rospy.Publisher('topic_central',controll, queue_size=20) ###### new
    print "Ready to read." ## Print a message
    time.sleep(0.5) ## wait 0.5 seconds
    rospy.spin() ## Do this for ever

if __name__ == '__main__':
	service_server() ##Execute  service_server function