#!/usr/bin/env python

import rospy ##import rospy library to use python
from servicios_prac.srv import my_srv_b ## import my_srv.srv from your srv folder of your package
from servicios_prac.srv import my_srv_c ## import my_srv.srv from your srv folder of your package
from servicios_prac.srv import my_srv_d ## import my_srv.srv from your srv folder of your package
import time ## import time to use sleep
import os


def handle_info(data): ## Service info (my_srv)
	scentral_server_3 = rospy.ServiceProxy('server_nd', my_srv_d) ##Declare that you gonna send information of my_srv between service server #############33333
	number=data.data1  ## take the information of the variable nm on my_srv
	fact=1
	for x in range(1,int(number)+1): 
		fact = fact * x 

	rospy.loginfo("numero par %s  and fac = %s\n" %(number, fact))  ## Print info to group2 (nodea2, nodeb2, nodec2)
	resp2=scentral_server_3(" ",str(fact)) #Send the three variables to server  ############################
	return fact		## you can skip it



def service_server():
    rospy.init_node('nc') ## Create a new node called  node_central
    s = rospy.Service('server_nc',my_srv_c, handle_info) ## declare s as Service server type, save the 
    
    print "Ready to read." ## Print a message
    time.sleep(0.5) ## wait 0.5 seconds
    rospy.spin() ## Do this for ever

if __name__ == '__main__':
	service_server() ##Execute  service_server function