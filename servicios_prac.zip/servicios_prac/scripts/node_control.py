#!/usr/bin/env python

import rospy
import time
import xbox
import xbox
import os
from movilv2.srv import my_srv
from movilv2.msg import wheel

joy = xbox.Joystick()         #Initialize joystick

my_input=' '
key_press=False #Bandera para leer si esta presionado algun botton
key_dir=' ' #Boton para la direccion de la tecla
count=0

keyboard_action=' '  #Varables para el menu
keyboard_press=False
position_=1

def Input_Controll():
	#button=' '
	global key_press

	my_dir= ' '
	if joy.A():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'A'
	else:
		pass	
	if joy.B():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'B'
	else:
		pass
	if joy.X():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'X'
	else:
		pass
	if joy.Y():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'Y'
	else:
		pass

	x_axis   = joy.leftX()        #X-axis of the left stick (values -1.0 to 1.0)
	y_axis = joy.leftY()

	x=joy.rightX()
	y= joy.rightY()

	##(x,y)    = joy.leftStick()    #Returns tuple containing left X and Y axes (values -1.0 to 1.0)
	triggerR  = joy.rightTrigger() #Right trigger position (values 0 to 1.0)
	triggerL  = joy.leftTrigger()
	
	
	if(x_axis>=0.3):
		my_dir='d'
		##return my_dir
		
	elif(x_axis<=-0.3):
		my_dir='a'
		##return my_dir
		
	elif(y_axis>=0.3):
		my_dir='w'
		#return my_dir
		
	elif(y_axis<=-0.3):
		my_dir='s'
		#return my_dir
	#else:
	elif(triggerR>=0.5 and triggerL==0):
		my_dir='R'
	elif(triggerR==0 and triggerL>=0.5):
		my_dir='L'

	else:
		pass

	if(x>=0.3):
		my_dir='d_'
		##return my_dir
		
	elif(x<=-0.3):
		my_dir='a_'
		##return my_dir
		
	elif(y>=0.3):
		my_dir='w_'
		#return my_dir
		
	elif(y<=-0.3):
		my_dir='s_'
		#return my_dir
	#else:
	else:
		pass



	if(my_dir>' '):
		key_press=True

	elif(my_dir==' '):
		key_press=False
 
	if my_dir<' ' or my_dir<'' or my_dir ==" ":
		my_dir="-" 

	return my_dir

if __name__ == '__main__':
	
	rospy.init_node('control_node', anonymous = True)
	pub = rospy.Publisher('topic_control', wheel, queue_size = 10) ##20
	rate = rospy.Rate(10)
	ob = wheel()

	while True:
		direction_controll=Input_Controll()
		
		ob.direction = direction_controll
		pub.publish(ob)
		
		scentral_server_ = rospy.ServiceProxy('scentral_server_', my_srv) ##Declare that you gonna send information of my_srv between service server #############33333
		resp2=scentral_server_(" "," "," ",direction_controll) #Send the three variables to server  ############################
		
		print(direction_controll)
#####################3