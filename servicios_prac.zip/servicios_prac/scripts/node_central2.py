#!/usr/bin/env python

import rospy ##import rospy library to use python
from omnidirectional.srv import my_srv ## import my_srv.srv from your srv folder of your package
import time ## import time to use sleep
import os

from omnidirectional.msg import control

######Control

# os.system("sudo python xbox.py")
#import my_saludo		
######
my_distace=''
my_gps=''
my_encoder=''

a=0
b=0

obj_dist=''
my_dir_=''

latitud1=''
longitud1=''

latitud2=''
longitud2=''
distance=0

utc_m=' '
utc_mid=' '

flag= True

latitud_now=''
longitud_now=''

my_list=[]

coords_1=(0,0)
coords_2=(0,0)
recorrido_gps=0.0



##########################import xbox library ######################33
import xbox
import os

# os.system("sudo python xbox.py")
#import my_saludo
joy = xbox.Joystick()         #Initialize joystick

my_input=' '
key_press=False #Bandera para leer si esta presionado algun botton
key_dir=' ' #Boton para la direccion de la tecla
count=0

keyboard_action=' '  #Varables para el menu
keyboard_press=False
position_=1

do_it=True

def Input_Controll():
	#button=' '
	global key_press

	my_dir= ' '
	if joy.A():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'A'
	else:
		pass	
	if joy.B():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'B'
	else:
		pass
	if joy.X():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'X'
	else:
		pass
	if joy.Y():                   #Test state of the A button (1=pressed, 0=not pressed)
		my_dir= 'Y'
	else:
		pass

	x_axis   = joy.leftX()        #X-axis of the left stick (values -1.0 to 1.0)
	y_axis = joy.leftY()
	(x,y)    = joy.leftStick()    #Returns tuple containing left X and Y axes (values -1.0 to 1.0)
	triggerR  = joy.rightTrigger() #Right trigger position (values 0 to 1.0)
	triggerL  = joy.leftTrigger()
	
	
	if(x_axis>=0.3 and y_axis==0):
		my_dir='d'
		##return my_dir
		
	elif(x_axis<=-0.3 and y_axis==0):
		my_dir='a'
		##return my_dir
		
	elif(y_axis>=0.3 and x_axis==0):
		my_dir='w'
		#return my_dir
		
	elif(y_axis<=-0.3 and x_axis==0):
		my_dir='s'
		#return my_dir
	#else:
	elif(triggerR>=0.5 and triggerL==0):
		my_dir='R'
	elif(triggerR==0 and triggerL>=0.5):
		my_dir='L'

	else:
		pass

	if(my_dir>' '):
		key_press=True

	elif(my_dir==' '):
		key_press=False
 
	return my_dir
#####################3


def Hora(mself):
	try:
		hora= mself[0:2]
		_min = mself[2:4]
		#####sec = mself[3:5] con segundero

		h=int(hora)
		m=int(_min)
		###s=int(sec) con segundero
		
		if(h==0):
		    h=24
		elif(h>=0 and h<6):
		    h=24+(h-6)
		else:
		    h=h-6
		c='.'

		if(h>=12):
			ind='PM'
		else:
			ind='AM'
		_my_hora=str(h)+c+str(m)+' '+ind
		##_my_hora=str(h)+c+str(m)+c+str(s) ##Con segundero
		return _my_hora
	except ValueError:
		pass


def handle_info(camara): ## Service info (my_srv)

	global my_distace
	global my_gps
	global my_encoder
	global obj_dist

	global recorrido_gps
	global do_it

	global my_dir_
	
	global my_list

	global flag

	global coords_1
	global coords_2

	global latitud1
	global longitud1
	global latitud2
	global longitud2
	global latitud_now
	global longitud_now
	global distance
	global utc_m
	global utc_mid
	global a
	global b

	obj=control()
	pub=rospy.Publisher('topic_central',control, queue_size=20)



	dis=camara.distance  ## take the information of the variable nm on my_srv
	g=camara.gps ## take the information of the variable ap on my_srv
	ec=camara.encoder ## take the information of the variable ed on my_srv
	dir_=camara.dir_control #Lee el valor de servicio en dir control.

	##dir_=Input_Controll()


	if dis>' ':
		my_distace=dis
		
		try:
			my_list=my_distace.split(',')
			obj_dist=my_list[2]
			my_encoder=my_list[1]
		except IndexError:
			pass			
	else:
		my_distace=my_distace
	
	if g>' ':
		my_gps=g
	else:
		my_gps=my_gps
	
	if ec>' ':
		my_encoder=ec
	else:
		my_encoder=my_encoder
	
	if dir_>' ':
		my_dir_=dir_
	else:
		my_dir_=my_dir_
	####

	#if float(obj_dist)>20:
		#obj.dir='w'
		#pub.publish(obj)
	#else:
		#obj.dir='-'
		#pub.publish(obj)
	if g>' ':
	    m_list=g.split(',')
	    latitud_now=(m_list[3]+','+m_list[4])
	    longitud_now=(m_list[5]+','+m_list[6])
	    utc_m=m_list[1]
	    utc_mid=Hora(utc_m)



	    # if(longitud_now >' ' and latitud_now> ' '):
	    # 	latitud_now=float(latitud_now)
	    # 	longitud_now=float(longitud_now)
	    # 	do_it=True
	    # else:
	    # 	do_it=False

	obj.latitud=latitud_now
	obj.longitud=longitud_now
	obj.encoder=my_list[1]
	##obj.direction=dir_

	pub.publish(obj)
	

	rospy.loginfo("\n--PSOC----\n\tdistance = %s\tencoder = %s\n--CONTROL----\n\tdir_=%s\n--GPS----\n\tUTC= %s,  Mid=%s, Ltd=%s, Long=%s" %(obj_dist, my_encoder,my_dir_,utc_m, utc_mid,latitud_now, longitud_now))  ## Print info to group2 (nodea2, nodeb2, nodec2)
	#print(dis)


	val = 10 ##return mi edad in sum
	return val		## you can skip it

def service_server():
    rospy.init_node('nodo_central') ## Create a new node called  node_central
    s = rospy.Service('my_server_',my_srv, handle_info) ## declare s as Service server type, save the  
    print "Ready to read." ## Print a message
    time.sleep(0.5) ## wait 0.5 seconds
    rospy.spin() ## Do this for ever

if __name__ == '__main__':
	service_server() ##Execute  service_server function
