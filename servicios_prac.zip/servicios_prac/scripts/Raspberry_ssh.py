#!/usr/bin/env python 

import rospy ##importar esta libreria para escribir un nodo de ros  
from movilv2.msg import RMC
from movilv2.msg import controll

########################################## Modulos y configuraciones iniciales para el robot ########################
import RPi.GPIO as GPIO
from serial import Serial
from time import sleep
import os

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(26,GPIO.OUT)

my_str=' '
vel='100'
bool_flag=True

os.system('sudo chmod 666 /dev/ttyACM0')
psoc=Serial('/dev/ttyACM0',9600)
print("Psoc started...")

def wait_counter(param1):
    count=0
    _wait=param1*1000000
    while True:
        count+=1
        if(count==_wait):
            break
        else:
            pass

def psoc_serial_send(mself):
    my_str = mself + '#'
    for i in range(0, len(my_str)):
        psoc.write(my_str[i])
        sleep(0.02)

def Program_Comunicacion(self):
    global my_str
    global bool_flag
    global vel
    count=0
    max_counts = 150000
    _w="$PSOC,u,%s,u,%s,u,%s,u,%s"
    _a='$PSOC,u,%s,d,%s,d,%s,u,%s'
    _s='$PSOC,d,%s,d,%s,d,%s,d,%s'
    _d='$PSOC,d,%s,u,%s,u,%s,d,%s'

    if(my_str!=self):
        bool_flag=True
    elif(my_str==self):
        bool_flag=False

    vel_i=int(vel)
    my_str=self
    try:
        if(my_str=='w'):
            GPIO.output(26,True)
            ##bluetooth.write('w')
            if(bool_flag==True):
                psoc_serial_send("$PSOC,u,%s,u,%s,u,%s,u,%s"%(vel,vel,vel,vel))
                bool_flag=False
            #######bluetooth_serial_send(self)
        elif(my_str=='s'):
            GPIO.output(26,False)
            if(bool_flag==True):
            #quitar.bluetooth_serial_send('s')
                psoc_serial_send('$PSOC,d,%s,d,%s,d,%s,d,%s'%(vel,vel,vel,vel))
                bool_flag=False
            ###########bluetooth_serial_send(self)
        elif(my_str=='a'):
            GPIO.output(26,False)
            #quitar.bluetooth_serial_send('a')
            if(bool_flag==True):
                psoc_serial_send('$PSOC,u,%s,d,%s,d,%s,u,%s'%(vel,vel,vel,vel))
                bool_flag=False
            ###########bluetooth_serial_send(self)
        elif(my_str=='d'):
            GPIO.output(26,False)
            #quitar.bluetooth_serial_send('d')
            if(bool_flag==True):
                psoc_serial_send('$PSOC,d,%s,u,%s,u,%s,d,%s'%(vel,vel,vel,vel))
                bool_flag=False
            ######bluetooth_serial_send(self)
        elif(my_str=='A'):
            GPIO.output(26,False)
            #quitar.bluetooth_serial_send('d')
            if(bool_flag==True):
                psoc_serial_send('$PSOC,u,%s,d,%s,d,%s,u,%s'%(vel,vel,vel,vel))
                bool_flag=False
            while True:
                count+=1
                if(count==max_counts):
                    break
                else:
                    pass
        elif(my_str=='B'):
            GPIO.output(26,False)
            #quitar.bluetooth_serial_send('d')
            if(bool_flag==True):
                psoc_serial_send('$PSOC,d,%s,u,%s,u,%s,d,%s'%(vel,vel,vel,vel))
                bool_flag=False
            wait_counter()

        elif(my_str=='-'):
            GPIO.output(26,False)
            #quitar.bluetooth_serial_send('-')
            if(bool_flag==True):
                psoc_serial_send('$PSOC,u,0,u,0,u,0,u,0')
                bool_flag=False
            ##while True:
            #######bluetooth_serial_send(self)
        elif(my_str=='L'):
            #GPIO.output(26,False)
            if(vel_i<=90):
                vel_i=vel_i+10
            else:
                vel_i=vel_i
            #quitar.bluetooth_serial_send('-')
        elif(my_str=='R'):
            #GPIO.output(26,False)
            if(vel_i>=10):
                vel_i=vel_i-10
            else:
                vel_i=vel_i
        elif(my_str=='X'):
            #GPIO.output(26,False)
            #quitar.bluetooth_serial_send('d')
            if(bool_flag==True):
                psoc_serial_send("$PSOC,u,%s,u,%s,u,%s,u,%s"%(vel,vel, vel, vel))
                bool_flag=False
                while True:
                    count+=1
                    if(count==max_counts):
                        break
                    else:
                        pass
                #wait_counter()
                psoc_serial_send('$PSOC,u,%s,d,%s,d,%s,u,%s'%(vel,vel,vel,vel)) #a
                count=0
                while True:
                    count+=1
                    if(count==max_counts):
                        break
                    else:
                        pass
                psoc_serial_send('$PSOC,d,%s,d,%s,d,%s,d,%s'%(vel,vel,vel,vel)) ##a
                count=0
                while True:
                    count+=1
                    if(count==max_counts):
                        break
                    else:
                        pass
                psoc_serial_send('$PSOC,d,%s,u,%s,u,%s,d,%s'%(vel,vel,vel,vel)) #d
                count=0
                while True:
                    count+=1
                    if(count==max_counts):
                        break
                    else:
                        pass
        elif(my_str=='Y'):
            #GPIO.output(26,False)
            #quitar.bluetooth_serial_send('d')
            if(bool_flag==True):
                psoc_serial_send("$PSOC,u,0,u,%s,u,%s,u,0"%(vel, vel))
                bool_flag=False
                while True:
                    count+=1
                    if(count==max_counts):
                        break
                    else:
                        pass
                #wait_counter()
                psoc_serial_send('$PSOC,u,%s,d,%s,d,%s,u,%s'%(vel,vel,vel,vel)) #a
                count=0
                while True:
                    count+=1
                    if(count==max_counts):
                        break
                    else:
                        pass
                psoc_serial_send('$PSOC,d,0,d,%s,d,%s,d,0'%(vel,vel)) ##3
                count=0
                while True:
                    count+=1
                    if(count==max_counts):
                        break
                    else:
                        pass
                psoc_serial_send('$PSOC,d,0,d,%s,d,%s,d,0'%(vel,vel)) #4
                count=0
                while True:
                    count+=1
                    if(count==max_counts):
                        break
                    else:
                        pass

                psoc_serial_send('$PSOC,u,%s,d,%s,d,%s,u,%s'%(vel,vel,vel,vel)) #a
                count=0
                while True:
                    count+=1
                    if(count==max_counts):
                        break
                    else:
                        pass
                psoc_serial_send('$PSOC,u,0,u,%s,u,%s,u,0'%(vel,vel)) #6
                count=0
                while True:
                    count+=1
                    if(count==max_counts):
                        break
                    else:
                        pass
        vel=str(vel_i)
    except:
        pass
################################################################################

def downloading(camara):
    global bool_flag
    a=camara.dir
    rospy.loginfo("Message: {0}| Flag: {1}| Vel: {2}\n".format(a,bool_flag,vel))
    Program_Comunicacion(a)
    sleep(0.1)

def listener():
	rospy.init_node('pi_node',anonymous=True)
	rospy.Subscriber('control_topic',controll, downloading)
	rospy.spin()

if __name__== '__main__': ##Error puse if name = a, en ves a == a,
	while True:
	    listener()
